package com.example.randomchoice

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var _addBTN : Button
    private lateinit var _clearBTN : Button
    private lateinit var _startBTN : Button

    private lateinit var _optionsList: TextView
    private lateinit var _inputOption : TextInputEditText

    var _wordCount : Int = 0
    val _wordsList = mutableListOf<String>()



    @SuppressLint("SetTextI18n")
    private fun addNewOption() {

        if(_inputOption.text.toString() != "" ){
            if(_wordCount < 15) {

                _optionsList.text =
                    "${_optionsList.text.toString()} \n ->  ${_inputOption.text.toString()}"
                _wordsList.add(_inputOption.text.toString())
                _inputOption.setText("")

                _wordCount += 1


            } else {

                val divErr = AlertDialog.Builder(this)

                divErr.setTitle("Error!") // Ustawienie tytułu komunikatu
                divErr.setMessage("Maximum number of words is 15") // Ustawienie opisu komunikatu
                divErr.setPositiveButton("OK",
                    DialogInterface.OnClickListener { dialog, id -> dialog.dismiss() })

                divErr.show()
            }

        } else {
            val divErr = AlertDialog.Builder(this)

            divErr.setTitle("Error!") // Ustawienie tytułu komunikatu
            divErr.setMessage("This item cannot be empty") // Ustawienie opisu komunikatu
            divErr.setPositiveButton(
                "OK",
                DialogInterface.OnClickListener { dialog, id -> dialog.dismiss() })

            divErr.show()
        }

    }


    private fun clearList() {
        _optionsList.text = ""
        _wordCount = 0
        _wordsList.clear()

    }


    private fun getResult() {

        if(!_wordsList.isEmpty()) {
            val _randomNumber: Int = Random.nextInt(_wordsList.size)
            val _choosenOption: String = _wordsList[_randomNumber]


            val divErr = AlertDialog.Builder(this)

            divErr.setTitle("Chosen Option") // Ustawienie tytułu komunikatu
            divErr.setMessage("Chosen option seems to be: $_choosenOption") // Ustawienie opisu komunikatu
            divErr.setPositiveButton(
                "Thank you",
                DialogInterface.OnClickListener { dialog, id -> dialog.dismiss() })

            divErr.show()
        } else
        {

            val divErr = AlertDialog.Builder(this)

            divErr.setTitle("Error") // Ustawienie tytułu komunikatu
            divErr.setMessage("List of options cannot be empty !") // Ustawienie opisu komunikatu
            divErr.setPositiveButton(
                "OK",
                DialogInterface.OnClickListener { dialog, id -> dialog.dismiss() })

            divErr.show()

        }

    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        _addBTN = findViewById(R.id.AddButton)
        _clearBTN = findViewById(R.id.ClearButton)
        _startBTN = findViewById(R.id.StartButton)

        _optionsList = findViewById(R.id.OptionsList)

        _inputOption = findViewById(R.id.InputOption)

        _addBTN.setOnClickListener { addNewOption() }
        _clearBTN.setOnClickListener { clearList() }
        _startBTN.setOnClickListener { getResult() }


    }
}
